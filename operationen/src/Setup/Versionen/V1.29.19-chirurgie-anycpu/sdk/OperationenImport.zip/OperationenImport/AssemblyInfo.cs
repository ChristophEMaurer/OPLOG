using System.Reflection;
using System.Runtime.CompilerServices;

//
// Allgemeine Informationen �ber eine Assembly werden �ber folgende Attribute 
// gesteuert. �ndern Sie diese Attributswerte, um die Informationen zu modifizieren,
// die mit einer Assembly verkn�pft sind.
//
[assembly: AssemblyTitle("Daten Import Template")]
[assembly: AssemblyDescription("Base class for data import")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("OP-LOG")]
[assembly: AssemblyCopyright("(C) Christoph Maurer")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		

//
// This version must NOT change in every build, as one must be able to add this assembly
// without requesting a different assembly for base types etc.
//

//
// Achtung: Diese Version NICHT aendern, das sie von ausgelieferten Plugins referenziert wird, Lubbecke z.B.!!!
//
[assembly: AssemblyVersion("3.2.0.0")]

