using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("OP-LOG Import")]
[assembly: AssemblyDescription("OP-LOG Import aus Unicode Text-Datei: MCC ISOP")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("OP-LOG")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("3.2.0.0")]

