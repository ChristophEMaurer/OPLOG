using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("OP-LOG Import")]
[assembly: AssemblyDescription("OP-LOG Import aus Unicode Text-Datei: ORBIS: 1 OPS-Kode und 1 Operateur pro Zeile")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Christoph Maurer")]
[assembly: AssemblyProduct("OP-LOG")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("3.2.0.0")]

