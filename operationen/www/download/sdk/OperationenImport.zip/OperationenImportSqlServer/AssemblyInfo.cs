using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("OP-LOG Import")]
[assembly: AssemblyDescription("OP-LOG Import von SQLServer")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright (c) Christoph Maurer")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("3.2.0.0")]

